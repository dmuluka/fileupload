angular.module('Assignment')
.constant("CONSTANT", {
	host: "localhost",
	port: 8000
})
