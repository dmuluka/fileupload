angular.module('Assignment.Fileupload', []);
