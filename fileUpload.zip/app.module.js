angular.module('Assignment', ['Assignment.Fileupload']);
